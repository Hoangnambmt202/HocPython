var oldShepherd = window.Shepherd;
H5P.Shepherd = Shepherd;
window.Shepherd = oldShepherd; 
